module.exports = function (grunt) {
    'use strict';
    // Project configuration
    
    grunt.initConfig({
            pkg: grunt.file.readJSON('package.json'),

            copy: {
                main: {
                    options: {
                        mode: true
                    },
                    src: [
                       '**',
                        '*.zip',
                        '!node_modules/**',
                        '!build/**',
                        '!css/sourcemap/**',
                        '!.git/**',
                        '!bin/**',
                        '!.gitlab-ci.yml',
                        '!bin/**',
                        '!tests/**',
                        '!phpunit.xml.dist',
                        '!*.sh',
                        '!*.map',
                        '!Gruntfile.js',
                        '!package.json',
                        '!.gitignore',
                        '!phpunit.xml',
                        '!README.md',
                        '!sass/**',
                        '!codesniffer.ruleset.xml',
                        '!vendor/**',
                        '!composer.json',
                        '!composer.lock',
                        '!package-lock.json',
                        '!phpcs.xml.dist',
                    ],
                    dest: 'wp-schema-pro/'
                }
            },

            compress: {
                main: {
                    options: {
                        archive: 'wp-schema-pro.zip',
                        mode: 'zip'
                    },
                    files: [
                        {
                            src: [
                                './wp-schema-pro/**'
                            ]

                        }
                    ]
                }
            },

            clean: {
                main: ["wp-schema-pro"],
                zip: ["wp-schema-pro.zip"]

            },

            makepot: {
                target: {
                    options: {
                        domainPath: '/',
                        potFilename: 'languages/wp-schema-pro.pot',
                        exclude: [
                            'admin/bsf-core',
                        ],
                        potHeaders: {
                            poedit: true,
                            'x-poedit-keywordslist': true
                        },
                        type: 'wp-plugin',
                        updateTimestamp: true
                    }
                }
            },

            addtextdomain: {
                options: {
                    textdomain: 'wp-schema-pro',
                },
                target: {
                    files: {
                        src: [
                            '*.php',
                            '**/*.php',
                            '!node_modules/**',
                            '!php-tests/**',
                            '!bin/**',
                            '!admin/bsf-core/**'
                        ]
                    }
                }
            }

        }
    );

    // Load grunt tasks
    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-contrib-compress');
    grunt.loadNpmTasks('grunt-contrib-clean');
    grunt.loadNpmTasks('grunt-wp-i18n');

    // Grunt release - Create installable package of the local files
    grunt.registerTask('release', ['clean:zip', 'copy', 'compress', 'clean:main']);

    // i18n
    grunt.registerTask('i18n', ['addtextdomain', 'makepot']);

    grunt.util.linefeed = '\n';
};