<?php
/**
 * Schemas Template.
 *
 * @package Schema Pro
 * @since 1.0.0
 */

if ( ! class_exists( 'BSF_AIOSRS_Pro_Schema_Person' ) ) {

	/**
	 * AIOSRS Schemas Initialization
	 *
	 * @since 1.0.0
	 */
	class BSF_AIOSRS_Pro_Schema_Person {

		/**
		 * Render Schema.
		 *
		 * @param  array $data Meta Data.
		 * @param  array $post Current Post Array.
		 * @return array
		 */
		public static function render( $data, $post ) {
			$schema = array();

			$schema['@context'] = 'https://schema.org';
			$schema['@type']    = 'Person';

			if ( isset( $data['name'] ) && ! empty( $data['name'] ) ) {
				$schema['name'] = wp_strip_all_tags( $data['name'] );
			}

			if ( ( isset( $data['pers-street'] ) && ! empty( $data['pers-street'] ) ) ||
				( isset( $data['pers-locality'] ) && ! empty( $data['pers-locality'] ) ) ||
				( isset( $data['pers-postal'] ) && ! empty( $data['pers-postal'] ) ) ||
				( isset( $data['pers-region'] ) && ! empty( $data['pers-region'] ) ) ) {

				$schema['address']['@type'] = 'PostalAddress';

				if ( isset( $data['pers-locality'] ) && ! empty( $data['pers-locality'] ) ) {
					$schema['address']['addressLocality'] = wp_strip_all_tags( $data['pers-locality'] );
				}

				if ( isset( $data['pers-region'] ) && ! empty( $data['pers-region'] ) ) {
					$schema['address']['addressRegion'] = wp_strip_all_tags( $data['pers-region'] );
				}

				if ( isset( $data['pers-postal'] ) && ! empty( $data['pers-postal'] ) ) {
					$schema['address']['postalCode'] = wp_strip_all_tags( $data['pers-postal'] );
				}

				if ( isset( $data['pers-street'] ) && ! empty( $data['pers-street'] ) ) {
					$schema['address']['streetAddress'] = wp_strip_all_tags( $data['pers-street'] );
				}
				
			}

			if ( isset( $data['per-email'] ) && ! empty( $data['per-email'] ) ) {
				$schema['email'] = wp_strip_all_tags( $data['per-email'] );
			}

			if ( isset( $data['per-gender'] ) && ! empty( $data['per-gender'] ) ) {
				$schema['gender'] = wp_strip_all_tags( $data['per-gender'] );
			}

			if ( isset( $data['per-member'] ) && ! empty( $data['per-member'] ) ) {
				$schema['memberOf'] = wp_strip_all_tags( $data['per-member'] );
			}

			if ( isset( $data['per-nationality'] ) && ! empty( $data['per-nationality'] ) ) {
				$schema['nationality'] = wp_strip_all_tags( $data['per-nationality'] );
			}

			if ( isset( $data['image'] ) && ! empty( $data['image'] ) ) {
				$schema['image'] = BSF_AIOSRS_Pro_Schema_Template::get_image_schema( $data['image'] );
			}

			if ( isset( $data['job-title'] ) && ! empty( $data['job-title'] ) ) {
				$schema['jobTitle'] = wp_strip_all_tags( $data['job-title'] );
			}

			if ( isset( $data['telephone'] ) && ! empty( $data['telephone'] ) ) {
				$schema['telephone'] = wp_strip_all_tags( $data['telephone'] );
			}

			if ( isset( $data['homepage-url'] ) && ! empty( $data['homepage-url'] ) ) {
				$schema['url'] = esc_url( $data['homepage-url'] );
			}

			if ( isset( $data['per-add-url'] ) && ! empty( $data['per-add-url'] ) ) {
				foreach ( $data['per-add-url'] as $key => $value ) {

					if ( isset( $value['same-as'] ) && ! empty( $value['same-as'] ) ) {
						$schema['sameAs'][ $key ] = wp_strip_all_tags( $value['same-as'] );
					}
				}
			}

			return apply_filters( 'wp_schema_pro_schema_person', $schema, $data, $post );
		}

	}
}
